import { StyleSheet, Text, View ,TextInput} from 'react-native'
import React from 'react'
//import { TextInput } from 'react-native-web'

const PaymentScreen = () => {
  return (
    <View>
        <View style={styles.i}>
     <Text>Enter Card Number</Text>
      <TextInput placeholder='xxxx xxxx xxxx xxxx' maxlength={16} />
      <Text>Enter month and year </Text>
      <TextInput placeholder='mm yy' maxlength={4} />
      <Text>Enter CVV</Text>
      <TextInput maxlength={3} /> 
    </View>
    </View>
  )
}

export default PaymentScreen

const styles = StyleSheet.create({
    i: {
        flex: 1,
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 60,
    }
})