import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity ,TextInput} from 'react-native'
import React, { useState } from 'react'
import { AntDesign } from '@expo/vector-icons';
import { navbtn, navbtnin, colors, navbtnout, btn2, hr80,incdecbtn ,incdecinput, incdecout } from '../globles/style'
import { firebase } from '../../firebase/FirebaseConfig'
//import { TextInput } from 'react-native-web';

const Productpage = ({ navigation, route }) => {
  const data = route.params;
  //console.log(data)
  if (route.params === undefined) {
    navigation.navigate('home')
  }
  const [quantity, setquatity] = useState('1');
  //const [addonquantity, setaddonquantity] = useState('0');


  const addtocart = () => {
    //console.log('add to cart')
    const docRef = firebase.firestore().collection('UserCart').doc(firebase.auth().currentUser.uid);
    const data1 = { data, Foodquantity: quantity }
    //console.log('data1',data) 
    docRef.get().then((doc) => {
      if (doc.exists) {
        docRef.update({
          cart: firebase.firestore.FieldValue.arrayUnion(data1)
        })
        alert("Added to cart")
      }
      else {
        docRef.set({
          cart: [data1],
        })
        alert("Added to cart")
      }
    })
  }
  const increaseQuantity=()=>{
    setquatity((parseInt(quantity)+1).toString())
  }
  const decreaseQuantity=()=>{
    if(parseInt(quantity)>1){
      setquatity((parseInt(quantity)-1).toString())
    }
  }
  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity onPress={() => navigation.navigate('home')} style={navbtnout}>
        <View style={navbtn}>
          <AntDesign name="back" size={24} color="black" style={navbtnin} />
        </View>
      </TouchableOpacity>
      <View style={styles.container1}>
        <View style={styles.s1}>
          <Image source={{
            uri: data.foodImageUrl
          }} style={styles.cardimgin} />
        </View>

      </View>
      <View style={styles.s2}>
        <View style={styles.s2in}>
          <Text style={styles.head1}>
            {data.foodName}
          </Text>
          <Text style={styles.head2}>
          ₹{data.foodPrice}({data.foodQuantity})
          </Text>

        </View>
        <View style={styles.s3}>
          <Text style={styles.head3}>About Food</Text>
          <Text style={styles.head4}>{data.foodDescription}</Text>

        </View>
        <View style={styles.container3}>
          <View style={hr80}></View>
          <Text style={styles.txt3}>Foodquantity</Text>
          <View style={incdecout}>
            <Text style={incdecbtn} onPress={()=>increaseQuantity()}>+</Text>
            <TextInput value={quantity} style={incdecinput}/>
            <Text style={incdecbtn} onPress={()=>decreaseQuantity()}>-</Text>
          </View>
        </View>
        <View style={styles.container4}>
          <View style={styles.c4in}>
            <Text style={styles.txt2}>Total price</Text>
            <Text style={styles.txt3}>₹{((parseInt(data.foodPrice)*parseInt(quantity))).toString()}/-</Text>
          </View>
          <View style={hr80}></View>
        </View>
        <View style={styles.btncont}>
          <TouchableOpacity style={btn2} onPress={() => addtocart()}>
            <Text style={styles.btntxt}>Add to Cart</Text>
          </TouchableOpacity>
          
        </View>

      </View>

    </ScrollView>
  )
}

export default Productpage

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '0fff',
    width: '100%',
  },
  container1: {
    flex: 1,
    backgroundColor: '0fff'
  },
  s1: {
    width: "100%",
    height: 300,
    backgroundColor: '0fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardimgin: {
    width: "100%",
    height: "100%"
  },
  s2: {
    width: '100%',
    padding: 20,
    position: 'relative',
    top: -30,
    backgroundColor: colors.col1,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  s2in: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  head1: {
    fontSize: 25,
    fontWeight: '500',
    color: colors.text1,
    width: 220,
    marginRight: 10,
  },
  head2: {
    fontSize: 20,
    fontWeight: '250',
    color: colors.text3,
  },
  s3: {
    backgroundColor:'#ffc270',
    padding: 20,
    borderRadius: 20,
  },
  head3: {
    fontSize: 30,
    fontWeight: '400',
    color: 'black',
  },
  head4: {
    marginVertical: 10,
    fontSize: 20,
    fontWeight: '400',
    color: '#696969',
  },
  s3in: {
    backgroundColor: colors.col1,
    padding: 10,
    borderRadius: 10,
    width: 130,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  head5: {
    color: colors.text3,
    fontSize: 20,
    fontWeight: '200',
    marginLeft: 10,
  },
  btntxt: {
    backgroundColor:'orange',
    color: 'black',
    paddingHorizontal: 10,
    paddingVertical: 5,
    fontSize: 15,
    borderRadius: 10,
    width: '90%',
    textAlign: 'center',

  },
  btncont: {
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 0,
    flexDirection: 'row',
  },
  container2: {
    width: '90%',
    backgroundColor: colors.col1,
    padding: 20,
    borderRadius: 20,
    alignSelf: 'center',
    marginVertical: 10,
    elevation: 10,
    alignItems: 'center',
  },
  txt1: {
    color: colors.text1,
    fontSize: 20,
    fontWeight: '200',

  },
  txt2: {
    color: colors.text3,
    fontSize: 25,
    fontWeight: '300',
    marginVertical: 10,

  },
  container2in: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  txt3: {
    color: colors.text1,
    fontSize: 18,
  },
  dash: {
    width: 1,
    height: 20,
    backgroundColor: colors.text1,
    marginHorizontal: 10,
  },
  c3in: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: '100%',
  },
  container3: {
    width: '90%',
    alignSelf: 'center',
    alignItems: 'center',
  },
  text4: {
    color: colors.text3,
    fontSize: 20,
    marginHorizontal: 10,
  },
  container4:{
    width:"90%",
    alignSelf:"center",
    alignItems:"center"
  },
  c4in: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  }
})