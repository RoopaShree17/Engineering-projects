import { StyleSheet, Text, View, StatusBar, TextInput, ScrollView, FlatList } from 'react-native'
import React, { useEffect, useState } from 'react'
import Homeheadnav from '../components/Homeheadnav'
import { colors } from '../globles/style'
import Categories from '../components/Categories'
import Offerslider from '../components/Offerslider'
import { AntDesign } from '@expo/vector-icons'
import { firebase } from '../../firebase/FirebaseConfig'
import Cardslider from '../components/Cardslider'
import { VirtualizedList } from 'react-native-web'
import BottomNav from '../components/BottomNav'
import { windowHeight } from '../components/BottomNav'
//import {firestore} from '@react-native-firebase/firestore'

const Homescreen=({navigation})=>{
  const [foodData, setFoodData] = useState([]);
  const [sweetData, setSweetData] = useState([]);
  const [snacksData, setSnacksData] = useState([]);
  const [powderData, setPowderData] = useState([]);

  const foodRef = firebase.firestore().collection('FoodData');

  useEffect(() => {
    foodRef.onSnapshot(snapshot => {
      setFoodData(snapshot.docs.map(doc => doc.data()))
    })
  }, [])

  useEffect(() => {
    setSweetData(foodData.filter(item => item.foodCategory === "sweets"))
    setSnacksData(foodData.filter(item => item.foodCategory === "snacks"))
    setPowderData(foodData.filter(item => item.foodCategory === "powder"))
  }, [foodData])

  const [search, setSearch] = useState('');
  ///console.log(search)

  return (
    <ScrollView style={styles.container}>
      <StatusBar />
      <Homeheadnav navigation={navigation}/>
     
      <View style={styles.bottomnav}>
                <BottomNav navigation={navigation} />
            </View>

      <View style={styles.searchbox}>
        <AntDesign name='search1' size={24} color='black' style={styles.searchicon} />
        <TextInput placeholder='Search' style={styles.input}
          onChangeText={(text) => { setSearch(text) }}
        />
      </View>
      {search != '' && <View style={styles.searchresultsouter}>
        <FlatList style={styles.searchresultsinner}
          data={foodData} renderItem={({ item }) => {
            if (item.foodName.toLowerCase().includes(search.toLowerCase())) {
              return (
                <View style={styles.searchresult}>
                  <AntDesign name='arrowright' size={24} color='black' />
                  <Text style={styles.searchresulttext}>{item.foodName}</Text>
                </View>
              )
            }
          }} />
      </View>}
      <Categories />
      <Offerslider />
      {/*<Cardslider title={"Today's special"} data={foodData}/>*/}
      <Cardslider title={"sweets"} data={sweetData} navigation={navigation} />
      <Cardslider title={"snacks"} data={snacksData} navigation={navigation}/>
      <Cardslider title={"powders"} data={powderData} navigation={navigation}/>
      <View style={styles.abc}></View>
    </ScrollView>
  )
}
export default Homescreen
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    //alignItems: 'center',
    width: '100%'
  },
  searchbox: {
    flexDirection: 'row',
    width: '90%',
    backgroundColor: 'white',
    borderRadius: 30,
    alignItems: 'center',
    padding: 10,
    margin: 20,
    elevation: 10,
  },
  input: {
    marginleft: 10,
    width: '90%',
    fontsize: 18,
    color: 'black',

  },
  searchicon: {
    color: 'orange'
  },
  seacrhresultsouter: {
    width: '100%',
    marginHorizontal: 30,
    height: '100%',
    backgroundColor: colors.col1,
},
searchresultsinner: {
    width: '100%',
},
searchresult: {
    width: '100%',
    flexDirection: 'row',
    // alignItems: 'center',
    padding: 5,
},
searchresulttext: {
    marginLeft: 10,
    fontSize: 18,
    color: "blue",
},
bottomnav: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: colors.col1,
    zIndex: 20,
},
abc:
{
  padding:23
}
})