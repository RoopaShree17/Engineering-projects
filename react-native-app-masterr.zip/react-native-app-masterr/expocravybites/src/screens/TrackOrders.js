import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function TrackOrders() {
  return (
    <View>
      <Text>TrackOrders</Text>
    </View>
  )
}

const styles = StyleSheet.create({})