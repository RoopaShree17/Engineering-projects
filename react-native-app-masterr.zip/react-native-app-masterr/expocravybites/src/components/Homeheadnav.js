import { StyleSheet, Text, View, Image , TouchableOpacity} from 'react-native'
import React from 'react'
//import logo from '../../assets/logo.png'
import { FontAwesome, Fontisto, FontAwesome5 } from '@expo/vector-icons'
//import { TouchableOpacity } from 'react-native-web'
//import { navigation } from 'react-native-navigation'
//import {colors} from './src/globles/style'

const Homeheadnav = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Fontisto name='nav-icon-list-a' size={24} color='black'
        style={styles.myicon} />
      <View style={styles.containerin}>

        <Image style={styles.pic} source={require('../../assets/logo.png')} />

      </View>
      <TouchableOpacity onPress={() => { navigation.navigate('userprofile') }}>
        <FontAwesome5 name='user-circle' size={24} color='black' style={styles.myicon} />
      </TouchableOpacity>
    </View>
  )
}

export default Homeheadnav
const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    padding: 10,
    alignItems: 'center',
    backgroundColor: 'white',
    elevation: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  containerin: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  myicon: {
    color: 'orange',

  },
  pic: {
    width: 105,
    height: 70
  },


})