import { StyleSheet, Text, View ,ScrollView ,Image } from 'react-native'
import React from 'react'
import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons'


export default function Categories() {
  return (
    <View style={styles.container}>
      <Text style={styles.head}>Categories</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.box}>
          <Image source={require("../../assets/icon_laddo.jpg")} style={styles.icon}/>
          <Text style={styles.text}>sweets</Text>
        </View>

        <View style={styles.box}>
          <Image source={require("../../assets/icon_powder.jpg")} style={styles.icon}/>
          <Text style={styles.text}>powders</Text>
        </View>

        <View style={styles.box}>
          <Image source={require("../../assets/icon_chakli.jpg")} style={styles.icon}/>
          <Text style={styles.text}>snacks</Text>
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
container:{
  backgroundColor:"white",
  width:"100%",
  //height:100,
  //alignitem:center,
  elevation:10,
  borderradius:10,
},
head:{
  color:"red",
  fontSize:25,
  fontWeight:"300",
  margin:10,
  alignitem:"center",
  paddingBottom:5,
  borderBottomColor:"red",
  borderBottomWidth:1,
},

box:{
  backgroundColor:"white",
  elevation:20,
  margin:10,
  padding:10,
  borderRadius:10,
  alignitem:"center",
  justifyContent:"center",
  flexDirection:"row",
},
icon:{
  marginRight:10,
  color:"black",
  width:100,
  height:70
},
text:{
  color:"black",
  paddingTop:20
}


})