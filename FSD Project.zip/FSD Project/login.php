<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="food";

$uname=$_POST['username'];
$pass=$_POST['password'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM login WHERE email='$uname' AND password='$pass'";
$result = $conn->query($sql);

if ($result->num_rows >= 1) {
 
  header("Location:http://localhost/FSD%20Project/index.php");
  exit();
  echo("success");// Replace with your URL
	
} else {
  echo "please enter correct username and password: " . $conn->error;
}

$conn->close();
?>